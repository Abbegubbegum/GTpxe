#!/bin/sh
/etc/local.d/run_diagnostic.start